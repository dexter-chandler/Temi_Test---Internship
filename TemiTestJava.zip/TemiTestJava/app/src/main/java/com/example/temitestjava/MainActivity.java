package com.example.temitestjava;

import android.net.ConnectivityManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.robotemi.sdk.NlpResult;
import com.robotemi.sdk.Robot;
import com.robotemi.sdk.TtsRequest;
import com.robotemi.sdk.listeners.OnRobotReadyListener;
import com.robotemi.sdk.navigation.listener.OnCurrentPositionChangedListener;
import com.robotemi.sdk.navigation.model.Position;
import org.jetbrains.annotations.NotNull;

import java.util.LinkedList;
import java.util.Queue;

public class MainActivity extends AppCompatActivity implements

        OnRobotReadyListener,
        OnCurrentPositionChangedListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    private static Robot mRobot;
    final Queue<String> queue = new LinkedList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize robot instance
        mRobot = Robot.getInstance();

        // Initialize Go-To position button
        final EditText editXCoordinate = findViewById(R.id.editXCoordinate);
        final EditText editYCoordinate = findViewById(R.id.editYCoordinate);
        final EditText editZCoordinate = findViewById(R.id.editZCoordinate);
        Button follow = findViewById(R.id.buttonFollow);
        Button goToPosition = findViewById(R.id.buttonGoToPosition);
        Button goToHome = findViewById(R.id.buttonGoToHome);
        Button goToDesk = findViewById(R.id.buttonGoToDesk);
        Button stopFollow =findViewById(R.id.buttonStopFollow);
        stopFollow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             mRobot.constraintBeWith();
                queue.add("Okay, I will wait here.");

                // Register TTS listener
                mRobot.addTtsListener(new Robot.TtsListener() {
                    @Override
                    public void onTtsStatusChanged(@NotNull TtsRequest ttsRequest) {
                        Log.i(TAG, "Status:" + ttsRequest.getStatus());
                        if (ttsRequest.getStatus() == TtsRequest.Status.COMPLETED) {
                            if (!queue.isEmpty()) {
                                mRobot.speak(TtsRequest.create(queue.remove(), true)); // do not display text; uses Google Text-to-Speech
                            }
                        }
                    }
                });
                // Command robot to speak
                mRobot.speak(TtsRequest.create(queue.remove(), false)); // do not display text, uses Google Text-to-Speech
            }


        });
        follow.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view) {
                mRobot.beWithMe();
                queue.add("Following you, lead the way!");

                // Register TTS listener
                mRobot.addTtsListener(new Robot.TtsListener() {
                    @Override
                    public void onTtsStatusChanged(@NotNull TtsRequest ttsRequest) {
                        Log.i(TAG, "Status:" + ttsRequest.getStatus());
                        if (ttsRequest.getStatus() == TtsRequest.Status.COMPLETED) {
                            if (!queue.isEmpty()) {
                                mRobot.speak(TtsRequest.create(queue.remove(), true)); // do not display text; uses Google Text-to-Speech
                            }
                        }
                    }
                });
                // Command robot to speak
                mRobot.speak(TtsRequest.create(queue.remove(), false)); // do not display text, uses Google Text-to-Speech
            }

        });
        goToPosition.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Coordinates are defined as distances (m) from the Home Base
                // where,
                // X is pointed directly away from the Home Base
                // Y is pointed to the left of the Home Base
                int xCoordinate = 0; // Robot's position wrt the Home Base [m]
                int yCoordinate = 0; // Robot's position wrt the Home Base [m]
                int yaw = 0; // Robot's yaw-rotation wrt the Home Base [deg]
                int Tilt = 0;
                // Convert input string to integer
                try {
                    xCoordinate = Integer.parseInt(editXCoordinate.getText().toString());
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }

                try {
                    yCoordinate = Integer.parseInt(editYCoordinate.getText().toString());
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }

                try {
                    Tilt = Integer.parseInt(editZCoordinate.getText().toString());
                } catch (NumberFormatException e) {
                    e.printStackTrace();
                }

                Log.i(TAG, "X: " + xCoordinate + " | Y: " + yCoordinate + " | Tilt: " + Tilt);

                // Send robot to the XY position
                mRobot.goToPosition(new Position((float) xCoordinate, (float) yCoordinate, (float) yaw, (int) Tilt));

                queue.add("On the Move!");

                // Register TTS listener
                mRobot.addTtsListener(new Robot.TtsListener() {
                    @Override
                    public void onTtsStatusChanged(@NotNull TtsRequest ttsRequest) {
                        Log.i(TAG, "Status:" + ttsRequest.getStatus());
                        if (ttsRequest.getStatus() == TtsRequest.Status.COMPLETED) {
                            if (!queue.isEmpty()) {
                                mRobot.speak(TtsRequest.create(queue.remove(), true)); // do not display text; uses Google Text-to-Speech
                            }
                        }
                    }
                });
                // Command robot to speak
                mRobot.speak(TtsRequest.create(queue.remove(), false)); // do not display text, uses Google Text-to-Speech
            }
        });

        goToHome.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // Coordinates are defined as distances (m) from the Home Base
                // where,
                // X is pointed directly away from the Home Base
                // Y is pointed to the left of the Home Base
                int xCoordinate = 0; // Robot's position wrt the Home Base [m]
                int yCoordinate = 0; // Robot's position wrt the Home Base [m]
                int yaw = 0; // Robot's yaw-rotation wrt the Home Base [deg]
                int Tilt = 0;
                // Send robot to the XY position
                mRobot.goToPosition(new Position((float) xCoordinate, (float) yCoordinate, (float) yaw, (int) Tilt));

                queue.add("Heading Home!");

                // Register TTS listener
                mRobot.addTtsListener(new Robot.TtsListener() {
                    @Override
                    public void onTtsStatusChanged(@NotNull TtsRequest ttsRequest) {
                        Log.i(TAG, "Status:" + ttsRequest.getStatus());
                        if (ttsRequest.getStatus() == TtsRequest.Status.COMPLETED) {
                            if (!queue.isEmpty()) {
                                mRobot.speak(TtsRequest.create(queue.remove(), true)); // do not display text; uses Google Text-to-Speech
                            }
                        }
                    }
                });
                // Command robot to speak
                mRobot.speak(TtsRequest.create(queue.remove(), false)); // do not display text, uses Google Text-to-Speech
            }
        });

        goToDesk.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                // Coordinates are defined as distances (m) from the Home Base
                // where,
                // X is pointed directly away from the Home Base
                // Y is pointed to the left of the Home Base
                int xCoordinate = 6; // Robot's position wrt the desk [m]
                int yCoordinate = 9; // Robot's position wrt the desk[m]
                int yaw = 0; // Robot's yaw-rotation wrt the Home Base [deg]
                int Tilt = 0;
                // Send robot to the XY position
                mRobot.goToPosition(new Position((float) xCoordinate, (float) yCoordinate, (float) yaw, (int) Tilt));

                queue.add("Heading To Your Desks!");

                // Register TTS listener
                mRobot.addTtsListener(new Robot.TtsListener() {
                    @Override
                    public void onTtsStatusChanged(@NotNull TtsRequest ttsRequest) {
                        Log.i(TAG, "Status:" + ttsRequest.getStatus());
                        if (ttsRequest.getStatus() == TtsRequest.Status.COMPLETED) {
                            if (!queue.isEmpty()) {
                                mRobot.speak(TtsRequest.create(queue.remove(), true)); // do not display text; uses Google Text-to-Speech
                            }
                        }
                    }
                });
                // Command robot to speak
                mRobot.speak(TtsRequest.create(queue.remove(), false)); // do not display text, uses Google Text-to-Speech
            }
        });
    }
    @Override
    protected void onStart() {
        super.onStart();
        // Add robot event listeners
        mRobot.addOnRobotReadyListener(this);
        mRobot.addOnCurrentPositionChangedListener(this);

    }

    @Override
    protected void onStop() {
        super.onStop();
        // Remove robot event listeners
        mRobot.removeOnRobotReadyListener(this);
        mRobot.removeOnCurrentPositionChangedListener(this);

    }

    @Override
    public void onRobotReady(boolean isReady) {
        if (isReady) {
            Log.i(TAG, "Robot is ready");
            mRobot.hideTopBar(); // hide temi's ActionBar when skill is active
        }
        if (isReady) {
            Robot.getInstance().setDetectionModeOn(true, 1.0f);
            Robot.getInstance().setTrackUserOn(true);
        }
    }

    @Override
    public void onCurrentPositionChanged(@NotNull Position position) {
        final TextView textViewPosition = findViewById(R.id.textViewPosition);
        String str = "X: " + position.getX() + " Y: " + position.getY();
        Log.i(TAG, str);
        textViewPosition.setText(str);
    }


}




